/*
 * funcs.cpp
 *
 *  Created on: Mar 09, 2020
 *      Author: linuxuser
 */

#include <iomanip>
#include <iostream>
#include <cppconn/driver.h>
#include <cppconn/exception.h>
#include <cppconn/resultset.h>
#include <cppconn/statement.h>
#include <string>
#include <cppconn/prepared_statement.h>
#include "funcs.hpp" //function declarations

using namespace sql;
using namespace std;
//this document is for function definitions
void insert_state(string id, string name, double pop, Connection * c)
{
	PreparedStatement * ps;
	try{
		string sql = "INSERT INTO State (stateID, stateName, AvgPopulation) VALUES ('" + id + "', '" + name + "', " + to_string(pop) + ");";
		ps = c -> prepareStatement(sql.c_str());
		ps -> executeUpdate();
	}
	 catch(SQLException &e)
	 {
		 cout << e.what() << endl;
	 }
	 delete ps; //clean up
	return;
}

void display_states(Connection * c)
{
	Statement * s = nullptr;
	s = c -> createStatement();
	ResultSet * rs = nullptr;
	string sql = "SELECT * FROM State";
	rs = s -> executeQuery(sql.c_str());
	cout << "--------------------- STATE REPORT ---------------------" << endl;
	cout << endl;
	cout << "State ID" << setw(20) << "State Name" << setw(25) << "Average Population" << endl;
	cout << "--------------------------------------------------------" << endl;
	while(rs -> next()) //as long as we are still reading from the result set
	{
		cout << rs -> getString("stateID") << setw(25) << rs -> getString("stateName") << setw(20) << rs -> getDouble ("AvgPopulation") << endl;
	} //end while loop

	cout << endl << "--------------------- ENDING REPORT ---------------------" << endl;

	delete rs;
	delete s;
	//we will close and delete the connection later;
	return;
}

void display_senators(Connection * c)
{
	Statement * s = nullptr;
	s = c -> createStatement();
	ResultSet * rs = nullptr;
	string sql = "SELECT * FROM Senator";
	rs = s -> executeQuery(sql.c_str());
	cout << "Here are the senators found in the database: " << endl;
	cout << "-------------------- SENATOR REPORT --------------------" << endl << endl;
	cout << "State" << setw(6) << "ID" <<  setw(20) <<"Senator Name"  << setw(19) << "DOB" << endl;
	cout << "--------------------------------------------------------" << endl;
	while(rs -> next())
	{
		cout << rs -> getString("State_stateID") << ":" << setw(10)
			 << rs -> getInt("idSenator") << setw(10)
			 << rs -> getString("FirstName") << setw(12)
			 << rs -> getString("LastName") << setw(20)
			 << rs -> getString ("DOB") << endl;
	}
	cout << endl << endl;
	delete rs; //clean up
	delete s; //clean up
	return;
}

void insert_senators(int sen_id,string sen_fn, string sen_ln, string sen_state, string sen_dob,Connection * c)
{
	PreparedStatement * ps;
	try{
		string sql = "INSERT INTO Senator (idSenator, lastName, firstName, State_stateID, DOB) VALUES (" + to_string(sen_id) + ", '" + sen_ln + "', '" + sen_fn + "', '" + sen_state +"', '" + sen_dob + "');";
		ps = c -> prepareStatement(sql.c_str());
		ps -> executeUpdate();
	}
	 catch(SQLException &e) //check if errors, will display .what() is the error
	 {
		 cout << e.what() << endl;
	 }
	 delete ps;
	return;
}

void display_bills_senators(Connection * c)
{
	Statement * s = nullptr;
	s = c -> createStatement();
	ResultSet * rs = nullptr;
	string sql = "SELECT idSenator, LastName, FirstName, State_stateID  FROM Senator";
	rs = s -> executeQuery(sql.c_str()); //we must conever the string into a c_str;
	cout << "Here are the Senator ID's you can use" << endl << endl;
	cout << "Senator ID" << setw(20)
		 << "First Name" << setw(15)
		 << "Last Name"  << setw(15)
		 << "State" 	 << endl;
	cout << "--------------------------------------------------------------" << endl;
	while(rs -> next()) //remember not to use rs.next(), since ResultSet is of a pointer type
	{
		cout << rs -> getInt("idSenator") << setw(20)
			 << rs -> getString("FirstName") << setw(15)
			 << rs -> getString("LastName") << setw(15)
			 << rs -> getString("State_stateID") << endl;
	}
	cout << endl;
	delete rs; //clean up
	delete s; //clean up
	return;
}

void insert_bill (string bid, string bname, string bdesc, string bdate, string bsenator, Connection * c)
{
	PreparedStatement * ps;
	try{
		string sql = "INSERT INTO Bills (BillID, BillName, BillDescription, BillDate, SenatorID_FK) VALUES (" + bid + ", '" + bname + "', '" + bdesc + "', '" + bdate + "', '" + bsenator +"');";
		ps = c -> prepareStatement(sql.c_str());
		ps -> executeUpdate();
	}
	catch(SQLException &e)
	{
		cout << "There was an error in the input, program terminated" << endl;
		cout << e.what() << endl;

	}
	delete ps; //clean up
	cout << "Bill  #"  + bid + "  was inserted successfully!" << endl<< endl;
	return;
}

void display_state_bills(Connection * c) //TODO: NOT EVENT STARTED, USE THIS GIVEN TEMPLATE
{
	Statement * s = nullptr;
	s = c -> createStatement();
	ResultSet * rs = nullptr;
	string sql = "SELECT idSenator, LastName, FirstName, State_stateID  FROM Senator";
	rs = s -> executeQuery(sql.c_str()); //we must convert the string into a c_str;
	cout << "Here are the state state id's you can use" << endl;
	cout << "Senator ID" << setw(10)
		 << "First Name" << setw(15)
		 << "Last Name"  << setw(15)
		 << "State" 	 << endl;
	cout << "----------------------------------------" << endl;
	while(rs -> next()) //remember not to use rs.next(), since ResultSet is of a pointer type
	{
		cout << rs -> getInt("idSenator") << setw(10)
			 << rs -> getString("FirstName") << setw(15)
			 << rs -> getString("LastName") << setw(15)
			 << rs -> getString("State_stateID") << endl;
	}
	cout << endl;
	delete rs; //clean up
	delete s; //clean up
	return;

}

void displayStates_ids(Connection * c)
{
	//display all available state ID's
	Statement * s = nullptr;
	s = c -> createStatement();
	ResultSet * rs = nullptr;
	string sql = "SELECT stateID FROM State";
	rs = s -> executeQuery(sql.c_str());

	if (!rs ->next()) cout << "No current states to display... Come Back Later!" << endl;
	else
	{
		while( rs -> next() )
		{
			cout << rs -> getString("stateID") << ", "; //TODO: get rid of the last comma, replace with a period(?)
		}
	}
	cout << endl;

	//clean up:
	delete s;
	delete rs;

	return;
}

bool checkDateFormat(string date)
{
	//convert carachters to string, to validate the date formatting
	string four(1, date[4]);
	string five(1, date[5]);
	string six(1, date[6]);
	string seven(1, date[7]);
	string eight(1, date[8]);
	string nine(1, date[9]);


	string month = five + six;
	string day = eight + nine;
	if(date[4]!= '-')
	{
		cout << "Incorrect Format of Date" << endl;
		cout << "Insertion to the database was cancelled" << endl;
		return false;
	}
	if(date[7] != '-')
	{
		cout << "Incorrect Format of Date" << endl;
		cout << "Insertion to the database was cancelled" << endl;
		return false;
	}
	if(stoi(month) > 12 || stoi(month) < 1)
	{
		cout << "Month can only be between 01 and 12" << endl;
		cout << "Insertion to the database was cancelled" << endl;
		return false;
	}
	if(stoi(day) > 31 || stoi(day) < 1)
	{
		cout << "Day of the month can only be between 01 and 31" << endl;
		cout << "Insertion to the database was cancelled" << endl;
		return false;
	}
	return true;
}

void showStateBills (string state, Connection * c) //using the view table
{
	/// --------------------- VIEW CREATION CODE BELOW -----------------------
	//CREATE VIEW StateBillsView AS SELECT
	//stateID, stateName, BillName, BillID
	//FROM State, Bills WHERE stateID =
	//(SELECT State_stateID FROM Senator
	//WHERE idSenator = (SELECT SenatorID_FK FROM Bills
	//WHERE BillID = BillID));

	Statement * s = nullptr;
	s = c -> createStatement();
	ResultSet * rs_bill = nullptr;
	string sql_bill = "SELECT stateName, BillName, BillID FROM StateBillsView WHERE stateID = '" + state + "'"; //all of the coumns from the view table
	rs_bill = s -> executeQuery(sql_bill.c_str());
	ResultSet * rs_test_emptiness = nullptr;
	string sql_test_emptiness = "SELECT * FROM StateBillsView WHERE stateID = '" + state + "'";
	rs_test_emptiness = s -> executeQuery(sql_test_emptiness);
	if(!rs_test_emptiness -> next())
	{
		cout << "State's Senators didn't pass any bills" << endl;
		//clean up
		delete s;
		delete rs_bill; //integration of multiple result_sets
		delete rs_test_emptiness;
		//create the test_emptiness variables to avoid pushing to the next line of the real query with the next() function
		//return
		return;
	}
	cout << "Bill ID" << setw(17) << "Bill Name" << setw(20) << "State Name"  << setw(18) << "Senator" << endl;
	cout << "=======" << setw(17) << "=========" << setw(20) << "=========="  << setw(18) << "=======" << endl;

	ResultSet * rs_senBill = nullptr;
	string sql_senBill = "";
	string sql_senatorInfo = "";
	ResultSet * rs_senInfo = nullptr;
	int bid;
	int senid;

	while(rs_bill->next())
	{
		bid = rs_bill -> getInt("BillID");
		cout << bid <<  setw(15) << rs_bill -> getString("BillName") << setw(20) << rs_bill ->getString("stateName");

		sql_senBill = "SELECT SenatorID_FK FROM Bills WHERE BillID = " + to_string(bid);
		rs_senBill = s -> executeQuery(sql_senBill.c_str());
		rs_senBill -> next(); //go to the next one, I thinkwe have to do this since not in a while loop
		senid = rs_senBill -> getInt("SenatorID_FK");
		sql_senatorInfo = "SELECT LastName, FirstName FROM Senator WHERE idSenator = " + to_string(senid);
		rs_senInfo = s -> executeQuery(sql_senatorInfo.c_str());
		rs_senInfo -> next(); //we have to move to the FIRST (next after 0th) result set resulted
		cout <<setw(22);
		cout << rs_senInfo -> getString("LastName") + ", " + rs_senInfo -> getString("FirstName");
		cout << endl; // finish line
	}


	cout << endl;
	//clean up:
	delete s;
	delete rs_senBill;
	delete rs_bill; //integration of multiple result_sets
	delete rs_senInfo;
	delete rs_test_emptiness;
	return;
}

void displayAllBills(Connection * c)
{
	Statement * s = nullptr;
	s = c -> createStatement();
	ResultSet * rs_allStates = nullptr;
	string sql_dispAllStates = "SELECT * FROM Bills"; // should I use select * or selecte x, y ,z....
	ResultSet * rs_test_emptiness = nullptr;
	string sql_test_emptiness = "SELECT * FROM Bills"; //check if there are any at all
	rs_test_emptiness = s -> executeQuery(sql_test_emptiness);
	//check for emptiness with a designated result set and sql query line
	if(!rs_test_emptiness -> next())
	{
		cout << "No Bills to display at the moment, come back later!" << endl;
		return; //get out of the function if no bills to display
	}

	rs_allStates = s -> executeQuery(sql_dispAllStates);
	cout << "Bill ID" << setw(31) << "Bill Name" << setw(227) << "Description" << setw(66) << "Date" << setw(22) << "Senator's ID" << endl;
	cout << "=======" << setw(31) << "=========" << setw(227) << "===========" << setw(66) << "====" << setw(22) << "============" << endl;
	while(rs_allStates -> next())
	{
		cout << rs_allStates -> getInt ("BillID") << setw(36)
			 << rs_allStates -> getString("BillName") << setw(255)
			 << rs_allStates -> getString("BillDescription") << setw(35)
			 << rs_allStates -> getString ("BillDate") << setw(18)
			 << rs_allStates -> getInt("SenatorID_FK") << endl;
	}
	return;
}
/*
 * TODO:
 * User Credentials Verificiation - check, debug, works, formatted
 * OPTION I - check, debug, works, formatted
 * OPTION II - check, debug, works, formatted
 * OPTION III - check, debug, works, formatted
 * OPTION IV - check, debug, works, formatted
 * OPTION V - check, debug, works, formatted
 * OPTION VI - check, debug, works, formatted
 * OPTION VII - check, debug, works, formatted
 *
 *FINISHED:
 */


