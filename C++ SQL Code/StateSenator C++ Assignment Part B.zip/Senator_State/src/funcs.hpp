/*
 * funcs.hpp
 *
 *  Created on: Mar 09, 2020
 *      Author: linuxuser
 */

//**** function Declarations ******** //
#ifndef FUNCS_HPP_
#define FUNCS_HPP_

#include <iomanip>
#include <iostream>
#include <cppconn/driver.h>
#include <cppconn/exception.h>
#include <cppconn/resultset.h>
#include <cppconn/statement.h>
#include <string>
#include <cppconn/prepared_statement.h>
#include "funcs.hpp" //function declarations
using namespace std;
using namespace sql;


void insert_state(string id, string name, double pop, Connection * c);
void display_states(Connection * c);
void display_senators(Connection * c);
void insert_senators(int sen_id,string sen_fn, string sen_ln, string sen_state, string sen_dob,Connection * c);
void display_bills_senators(Connection * c);
void insert_bill (string bid, string bname, string bdesc, string bdate, string sen_id, Connection * c);
void displayStates_ids(Connection * c);
void displayAllBills(Connection *c);
void showStateBills(string state, Connection * c);
bool checkDateFormat(string date);
#endif /* FUNCS_HPP_ */
