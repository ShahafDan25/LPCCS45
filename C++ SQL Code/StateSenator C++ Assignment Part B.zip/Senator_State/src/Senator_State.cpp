//============================================================================
// Name        : Senator_State.cpp
// Author      : ShahafDan
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <iomanip>
#include <cstdlib>
//#include "mysql_connection.h"
#include <cppconn/driver.h>
#include <cppconn/exception.h>
#include <cppconn/resultset.h>
#include <cppconn/statement.h>
#include <string>
#include <cstring>
#include <cppconn/prepared_statement.h>
#include "funcs.hpp" //function declarations

using namespace sql;
using namespace std;



int main()
{
	Connection *c = nullptr; //only one connection to be generated, it should be passed dynamically to all functions instead of generating new ones everytime
	Driver * d = nullptr;

	d = get_driver_instance();
	cout << "Please insert your database credentials" << endl;

	//string un = getUN();
	//string pw = getPass();
	string un;
	string pw;

	//---------- CREDENTIALS VERIFICATION -----------------------//
	cout << "Username: ";
	cin >> un;
	cout << endl << "Password: ";
	cin >> pw;
	cout << endl;

	//we now have the credentials storedin variables
	cout << endl << "----------------------------------" << endl;
	cout << "Connecting to the Database ..." << endl;
	try
	{
		c = d -> connect ("thekomanetskys.com:33066", un, pw); //if connection is wrong
		c -> setSchema ("cs45Student26");
	}
	catch(SQLException &e)
	{
		cout << "Connection Error. Program is Terminated. " << endl;
		cout << e.what() << endl;
		//terminate program??
	}
	cout << "Connected!" << endl;
	cout << "----------------------------------" << endl;
	string answer; // answer input
	//char sname [20]; //state name

	string sname;
	string sid; //state id
	string sen_fn; //first name
	string sen_ln; //last name
	string sen_state; //senator's state
	int sen_id; //senator id
	string sen_dob; //date of birth
	double apop; //average population of a state

	//bill variables
	string billid;
	//string bill_name;
	string bill_desc; //convert to string later
	string bill_name;//character array
	string bill_date;//character array
	string bill_senator;

	//option 6
	string stateChosen;
	do
	{
		cout << endl;
		cout << "Choose (Main Menu): " << endl;
		cout << "=================== " << endl;
		cout << "< - 1 - >  Insert State(s)"<< endl <<
				"< - 2 - >  Display States" << endl <<
				"< - 3 - >  Enter Senator(s)"<< endl <<
				"< - 4 - >  Display Senators " << endl <<
				"< - 5 - >  Enter Bill(s) " << endl <<
				"< - 6 - >  Display State Bills " << endl <<
				"< - 7 - >  Display All Bills " << endl <<
				"< - x - >  Exit Program" << endl;
		cin >> answer;
		if(answer == "1")
		{

			cout << "Enter as many states as you wish (Enter 99 to stop)." << endl;

			cout << "Enter State ID " << endl;
			cin >> sid;
			while(sid != "99")
			{
				cout << "Enter State Name" << endl;
				cin.get(); //open up to insertion
				getline(cin, sname); //put input into the sname variable
				cout << "Insert Population" << endl;
				cin >> apop;
				insert_state(sid, sname, apop, c);
				cout  << "************************************************" << endl;
				cout << "Enter State ID" << endl;
				cin >> sid;
			}
			cout << "Finished Inserting States" << endl;

			//idea create a verification table, where you can't insert the same state twice

		}
		else if (answer == "2")
		{
			cout << "Displaying States in the Database: " << endl;
			display_states(c);
		}
		else if(answer == "3")
		{
			insert_senator_id:
			cout << "Enter Senator's ID (6 digits  |  99 to Exit)" << endl;
			cin	 >> sen_id;
			while(sen_id != 99)
			{
				if (to_string(sen_id).length() != 6)
				{
					cout << "length of id must be 6 digits " << endl;
					goto insert_senator_id;
				}
				cout << "Enter Senator's First Name" << endl;
				cin >>sen_fn;
				cout << "Enter Senator's Last Name" << endl;
				cin >>sen_ln;
				sen_state_prompt:
				cout << "Enter Senator's State's ID (2 letters  |  'List' for available states)" << endl;
				cin >>sen_state;
				if(sen_state == "list")
				{
					displayStates_ids(c);
					goto sen_state_prompt;
				}
				cout << "Enter Senator's Date of Birth (format: yyyy-mm-dd)" << endl;
				cin >>sen_dob;
				if(!checkDateFormat(sen_dob))
				{
					break;
				}
				insert_senators(sen_id, sen_fn, sen_ln, sen_state, sen_dob, c); //we need to pass the connection variable, c, too;
				cout << "********************************************************************* " << endl;
				cout << "Enter Senator's ID (6 digits)" << endl;
				cin >> sen_id;
			}


		}
		else if (answer == "4")
		{
			cout << "Displaying Senators: " << endl;
			display_senators(c);
		}
		else if (answer == "5")
		{
			//Enter Bills
			//call insert function
			cout << "Insert Bill ID (Enter 99 to stop)" << endl;
			cin >> billid;
			while(billid != "99")
			{
				cout << "Enter Bill Name" << endl;
				cin.get();
				getline(cin, bill_name); //the space is added to get rid of the dropping of the first character when inserting to the database
				//bill_name = " " + bill_name;//  ^
				cout << "Enter Bill Description" << endl;
				cin.get();
				getline(cin, bill_desc); //needed to include cstring I guess
				cout << "Enter Bill's Date (format: yyyy-mm-dd)" << endl;
				cin >> bill_date;
				if(!checkDateFormat(bill_date))
				{
					break;
				}
				insert_bill_senator: //label for a goto
				cout << "Enter ID of the bill's Senator (Enter 'List' to list)" << endl;
				cin >> bill_senator;
				if(bill_senator == "list")
				{
					display_bills_senators(c);
					goto insert_bill_senator;
				}
				insert_bill(billid, bill_name, bill_desc, bill_date, bill_senator, c); //TODO : change data types to work later, from arraycharacters to strings (?) wifi access to check how
				//function call now
				cout << "---------------------------------------------------" << endl;
				cout << "Insert Bill ID (Enter 99 to Stop)" << endl;
				cin >> billid;
			}
		}
		else if (answer == "6")
		{
			//Display State Bills
			cout << "Choose a State to display bills ('99' to stop  |  'list' for available states)" << endl;

			cin >> stateChosen;

			while(stateChosen != "99")
			{
				//check for existence of state in database

				if(stateChosen == "list") displayStates_ids(c);
				else
				{
					if(stateChosen == "99") break; //exit the loop, play menu again
					else showStateBills(stateChosen, c);
				}
				cout << endl << "Enter a State ID to display its bills ('99' to stop  |  'list' for available states)" << endl << endl;
				cin >> stateChosen;

			}
			//call insert function
		}
		else if (answer == "7")
		{
			//display all bills
			displayAllBills(c);
		}
		else if(answer != "x") cout << "Not an option. Please pick a different option"  << endl;
	}while(answer!="x");

	cout << "Goodbye! Thanks for using our program! " << endl;
	//close connection
	c->close();
	delete c; //now delete it
	return 0;
}


