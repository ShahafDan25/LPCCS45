//============================================================================
// Name        : Senator_State.cpp
// Author      : ShahafDan
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <iomanip>
#include <mysql_connection.h>
#include <cppconn/driver.h>
#include <cppconn/exception.h>
#include <cppconn/resultset.h>
#include <cppconn/statement.h>
#include <string>
#include <cppconn/prepared_statement.h>


using namespace sql;
using namespace std;


void insert_state(string id, string name, double pop, Connection * c)
{
	PreparedStatement * ps;
	try{
		string sql = "INSERT INTO State (stateID, stateName, AvgPopulation) VALUES ('" + id + "', '" + name + "', " + to_string(pop) + ");";
		ps = c -> prepareStatement(sql.c_str());
		ps -> executeUpdate();
	}
	 catch(SQLException &e)
	 {
		 cout << e.what() << endl;
	 }
	 delete ps; //clean up
	return;
}

void display_states(Connection * c)
{
	Statement * s = nullptr;
	s = c -> createStatement();
	ResultSet * rs = nullptr;
	string sql = "SELECT * FROM State";
	rs = s -> executeQuery(sql.c_str());
	cout << "--------------------- STATE REPORT ---------------------" << endl;
	cout << endl;
	cout << "State ID \t State Name \t Average Population" << endl;
	cout << "--------------------------------------------------------" << endl;
	while(rs -> next()) //as long as we are still reading from the result set
	{
		cout << rs -> getString("stateID") << "\t\t" << rs -> getString("stateName") << "\t\t\t" << rs -> getDouble ("AvgPopulation") << endl;
	} //end while loop

	cout << endl << "--------------------- ENDING REPORT ---------------------" << endl;

	delete rs;
	delete s;
	//we will close and delete the connection later;
	return;
}
void display_state_ids(Connection * c)
{
	Statement * s = nullptr; //nullptr and not just null because it is a pointer;
	s = c -> createStatement();
	ResultSet * rs = nullptr;
	string sql = "SELECT stateID, stateName FROM State";
	rs = s -> executeQuery(sql.c_str()); //we must conever the string into a c_str;
	cout << "Here are the state state id's you can use" << endl;
	int counter = 0;
	while(rs -> next()) //remember not to use rs.next(), since ResultSet is of a pointer type
	{
		cout << rs -> getString ("stateID") << "(" << rs -> getString("stateName")<< "), ";
		counter ++;
		if(counter % 5) cout << "\t"; //nice display properties added
		else cout << endl; //nice display properties added
	}
	cout << endl;
	delete rs; //clean up
	delete s; //clean up
	return;
}

void display_senators(Connection * c)
{
	Statement * s = nullptr;
	s = c -> createStatement();
	ResultSet * rs = nullptr;
	string sql = "SELECT * FROM Senator";
	rs = s -> executeQuery(sql.c_str());
	cout << "Here are the senators found in the database: " << endl;
	cout << "---------------------SENATOR REPORT---------------------" << endl;
	cout << "State \t ID \t Senator Name \t\t\t DOB" << endl;
	cout << "--------------------------------------------------------" << endl;
	while(rs -> next())
	{
		cout << rs -> getString("State_stateID") << ":\t"
			 << rs -> getInt("idSenator") << "\t"
			 << rs -> getString("FirstName") << " "
			 << rs -> getString("LastName") << "\t\t"
			 << rs -> getString ("DOB") << endl;
	}
	cout << endl << endl;
	delete rs; //clean up
	delete s; //clean up
	return;
}

void insert_senators(int sen_id,string sen_fn, string sen_ln, string sen_state, string sen_dob,Connection * c)
{
	PreparedStatement * ps;
	try{
		string sql = "INSERT INTO Senator (idSenator, lastName, firstName, State_stateID, DOB) VALUES (" + to_string(sen_id) + ", '" + sen_ln + "', '" + sen_fn + "', '" + sen_state +"', '" + sen_dob + "');";
		ps = c -> prepareStatement(sql.c_str());
		ps -> executeUpdate();
	}
	 catch(SQLException &e) //check if errors, will display .what() is the error
	 {
		 cout << e.what() << endl;
	 }
	 delete ps;
	return;
}
int main()
{
	Connection *c = nullptr; //only one connection to be generated, it should be passed dynamically to all functions instead of generating new ones everytime
	Driver * d = nullptr;

	d = get_driver_instance();

	try
	{
		c = d -> connect ("thekomanetskys.com:33066", "cs45Student26", "Sdan3189@CS45"); //if connection is wrong
		c -> setSchema ("cs45Student26");
	}
	catch(SQLException &e)
	{
		cout << "You had an error somewhere, please be better" << endl;
		cout << e.what() << endl;
	}
	string answer; // answer input
	char sname [20]; //state name
	string sid; //state id
	string sen_fn; //first name
	string sen_ln; //last name
	string sen_state; //senator's state
	int sen_id; //senator id
	string sen_dob; //date of birth
	double apop; //average population of a state
	do
	{
		cout << "Choose: " << endl;
		cout << "< - 1 - >  Insert State(s).\n< - 2 - >  Display States.\n< - 3 - >  Enter Senator(s).\n< - 4 - >  Display Senators\n< - x - >  Exit Program" << endl;
		cin >> answer;
		if(answer == "1")
		{

			cout << "Enter as many states as you wish. Enter 99 for State ID to stop" << endl;

			cout << "Enter State ID " << endl;
			cin >> sid;
			while(sid != "99")
			{
				cout << "Enter State Name" << endl;
				cin >> sname; //I just hope state names are going to be inserted as ont string, without any white spaces
				//cin.getline(sname, 20); // in order to use "getline", we must define a maximum length, and define the storing variable as an array of characters
				cout << "Insert Population" << endl;
				cin >> apop;
				insert_state(sid, sname, apop, c);
				cout  << "************************************************" << endl;
				cout << "Enter State ID" << endl;
				cin >> sid;
			}


			//idea create a verification table, where you can't insert the same state twice

		}
		else if (answer == "2")
		{
			cout << "Displaying States in the Database: " << endl;
			display_states(c);
		}
		else if(answer == "3")
		{
			cout << "Enter as many senators as you wish. Enter 99 for Senator ID to stop" << endl;

			insert_senator_id:
			cout << "Enter Senator's ID (6 digits)" << endl;
			cin	 >> sen_id;
			while(sen_id != 99)
			{
				if (to_string(sen_id).length() != 6)
				{
					cout << "length of id must be 6 digits " << endl;
					goto insert_senator_id;
				}
				cout << "Enter Senator's First Name" << endl;
				cin >>sen_fn;
				cout << "Enter Senator's Last Name" << endl;
				cin >>sen_ln;
				sen_state_prompt:
				cout << "Enter Senator's State's ID (2 letters). Enter 'list' to see available state id's" << endl;
				cin >>sen_state;
				if(sen_state == "list")
				{
					display_state_ids(c);
					goto sen_state_prompt;
				}
				cout << "Enter Senator's Date of Birth (format: yyyy-mm-dd)" << endl;
				cin >>sen_dob;
				insert_senators(sen_id, sen_fn, sen_ln, sen_state, sen_dob, c); //we need to pass the connection variable, c, too;
				cout << "********************************************************************* " << endl;
				cout << "Enter Senator's ID (6 digits)" << endl;
				cin >> sen_id;
			}


		}
		else if (answer == "4")
		{
			cout << "Displaying Senators: " << endl;
			display_senators(c);
		}
		else if(answer != "x") cout << "Not an option. Please pick a different option"  << endl;
	}while(answer!="x");

	cout << "Goodbye! Thanks for using our program! " << endl;
	//close connection
	c->close();
	delete c; //now delete it
	return 0;
}


