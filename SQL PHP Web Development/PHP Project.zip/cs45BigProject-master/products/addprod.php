<?php
	$db = new mysqli('thekomanetskys.com', 'cs45Student26', 'Sdan3189@CS45', 'cs45Student26', 33066);
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Add a Product</title>
		<!-- BOOTSTRAP FOR CSS LINK -->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <!-- HARD CODED CSS (by Shahaf Dan) -->
		<link rel = "stylesheet" type = "text/css" href = "../index.css" />
	</head>
	<body class = "body purpleback">
		<h1>Add a Product</h1>
		<h4>cs45Student26 | Shahaf Dan</h4>
		<p>This form will call the <strong>prodAdd.php</strong> file which will insert a product into the product table</p>
		<div class = "center framer">
			<h1>Add a New Product</h1>
			
			<form action="prodAdd.php" method="post">
			<table class = " table">
					<tr>
						<td class = "pull-left"><strong>Product Code (1-999999): </strong></td>
						<td><input class = "input" placeholder = "  Product Code" type = "number" name="ProdCode" type="number" min="1" max="999999"></td>
					</tr>
					<tr>
						<td class = "pull-left"><strong>Description: </strong></td>
						<td><input class = "input" placeholder = "  Description" name="ProdDesc" type="text"></td>
					</tr>
					<tr>
						<td class = "pull-left"><strong>Inventory Date (yyyy-mm-dd): </strong></td>
						<td><input class = "input" placeholder = "  Date" name="InvDate" type="text"></td>
					</tr>
					<tr>
						<td class = "pull-left"><strong>Quantity On Hand (1-999999): </strong></td>
						<td><input class = "input" placeholder = "  Quantity On Hand" name="QtyOH" type="number" min="1" max="999999"></td>
					</tr>
					<tr>
						<td class = "pull-left"><strong>Minimum Quantity (1-999999): </strong></td>
						<td><input class = "input" placeholder = "  Minimum Quantity" name="MinQty" type="number" min="1" max="999999"></td>
					</tr>
					<tr>
						<td class = "pull-left"><strong>Price (.01 - 9999.99): </strong></td>
						<td><input class = "input" placeholder = "  Price" name="ProdPrice" type="number" min=".01" max="9999.99" step="0.01"></td>
					</tr>
					<tr>
						<td class = "pull-left"><strong>Discount Percent (0 - 20): </strong></td>
						<td><input class = "input" placeholder = "  Discount" name="DiscPct" type="number" min="0" max="20"></td>
					</tr>
					<tr>
						<td class = "pull-left"><strong>From Vendor: </strong></td>
						<td><select class = "input" name="vendors">
							<?php
								$sql = "SELECT V_Code, V_Name FROM Vendor";
								$s = $db -> prepare($sql);
								$s -> execute();
								$s -> store_result();
								$s -> bind_result($vcode, $vname);
								while($s -> fetch())
								{
									echo '<option value = '.$vcode.'>'.$vname.' [ '.$vcode.' ] </option>';
								}
							?>
						</select></td>
					</tr>
				</table>
				<button name = "submit" class = "btn btn-success" value = "Add Product"> SUBMIT </button>
			</form>
			<hr>
			<button class = "btn btn-info inline" onclick = "location.replace('./index.html')";> Invoice Home Page</button>
			<button class = "btn btn-info inline" onclick = "location.replace('../index.html')";> Main Home Page</button>
		</div>
	</body>
	<footer class = "footer">
        <p>Las Positas College  |   CS 45 : Database Programming Course</p> 
        <p>Copyright, May 2020  |  cs45Student26 User of <u>www.thekomanetskys.com</u></p>
        <h6><strong>Produced and Powered by Shahaf Dan</strong> </h6>
    </footer>
</html>
<?php mysqli_close($db);?>

