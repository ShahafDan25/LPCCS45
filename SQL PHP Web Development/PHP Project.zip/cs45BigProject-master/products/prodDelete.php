<?php
// code to add a new product to the database
ini_set("display_errors",1); //display initial errors of connecting to db
error_reporting(E_ALL);
$db = new mysqli('thekomanetskys.com', 'cs45Student26', 'Sdan3189@CS45', 'cs45Student26', 33066);
$p_code = trim($_POST['prodCode']);
//if produc not found in the db: notify, go back
//else: execute query
    //if query fails: notify, goback
    //else: success, go back
$sql_check = "SELECT Prod_Code FROM Product WHERE Prod_Code = ".$p_code.";";
$s = $db -> prepare($sql_check);
$s -> execute();
$s -> store_result();
$s -> bind_result($pcode);
if(!$s -> fetch()) //if query returns nothing = product not found
{
    echo '<script>alert("Product Code Not Found in the Database");</script>';
}
else
{
    $sql = "DELETE FROM Product WHERE Prod_Code = ".$p_code.";";
    if ($db->query($sql) === TRUE)  echo '<script>alert("Product Deleted Succesfully!");</script>';
    else echo "Error: " . $sql . "<br>" . $db->error; //display error if not inserted appropiately
}
//go back:
echo '<script>location.replace("index.html");</script>';
?>
<?php mysqli_close($db);?>
