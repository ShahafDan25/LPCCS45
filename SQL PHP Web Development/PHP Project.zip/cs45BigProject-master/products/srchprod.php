<?php
    ini_set("display_errors",1); //display initial errors of connecting to db
    error_reporting(E_ALL);
    $db = new mysqli('thekomanetskys.com', 'cs45Student26', 'Sdan3189@CS45', 'cs45Student26', 33066);
    $pname = trim($_POST['searchterm']);
?>
<!DOCTYPE html>
<html>
    <head>
    <title>Products Table</title>
		<!-- BOOTSTRAP FOR CSS LINK -->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <!-- HARD CODED CSS (by Shahaf Dan) -->
		<link rel = "stylesheet" type = "text/css" href = "../index.css" />
    </head>
    <body class = "body purpleback">
        <h1> Produc Search Results </h1>
        <h4>cs45Student26 | Shahaf Dan</h4>
        <hr>
        <div class = "center framer">
        <table class = "table">
            <?php
                //functions to populate the table:
                if (isset($_POST['allProd'])) $rows =  allProdTable($db, $pname);
                elseif(isset($_POST['similarto'])) $rows =  similarToTable($db, $pname);
                else $rows = exactName($db, $pname);
            ?>
            <br>
            <h5> Results Returned: <?php echo $rows; ?> </h5>
        </table>
        </div>
        <hr>
        <div class = "center">
            <button class = "btn btn-info inline" onclick = "location.replace('./findprod.html')";> Search Again</button>
            <button class = "btn btn-info inline" onclick = "location.replace('./index.html')";> Product Home Page</button>
            <button class = "btn btn-info inline" onclick = "location.replace('../index.html')";> Main Home Page</button>
        </div>
        <br>
    </body>
    <footer class = "footer">
        <p>Las Positas College  |   CS 45 : Database Programming Course</p> 
        <p>Copyright, May 2020  |  cs45Student26 User of <u>www.thekomanetskys.com</u></p>
        <h6><strong>Produced and Powered by Shahaf Dan</strong> </h6>
    </footer></html>
<?php
    //FUNCTIONS::
    function similarToTable($db, $pname)
    {
        $sql = "SELECT Prod_Code, P_Description,  P_QtyOnHand, P_Price, V_Code FROM Product WHERE P_Description LIKE '%".$pname."%' ORDER BY Prod_Code ASC;";
        $s = $db -> prepare($sql);
        $s -> execute();
        $s -> store_result();
        $s -> bind_result($pc, $desc, $qty, $price, $vc); //pc = product code, vc = vendor code
        $tableInfo = '';
        $counter = 0;
        while($s -> fetch())
        {
            $counter++;
            $tableInfo .= '<tr>';
            $tableInfo .= '<td>'.$pc.'</td>';
            $tableInfo .= '<td>'.$desc.'</td>';
            $tableInfo .= '<td>'.$qty.'</td>';
            $tableInfo .= '<td>'.$price.'</td>';
            $tableInfo .= '<td>'.$vc.'</td>';
            $tableInfo .= '</tr>';
        }
        if(strlen($tableInfo) < 2) echo 'No Results';
        else 
        {
            echo "<table class = 'table'>
            <thead>
                <tr>
                    <th> Code </th>
                    <th> Description </th>
                    <th> On - Hand Quantity </th>
                    <th> Price </th>
                    <th> Vendor Code </th>
                <tr>
            </thead>
            <tbody>";
            echo $tableInfo;
            echo "</tbody>
            </table>";
        }
        return $counter;
    }
    function allProdTable($db)
    {
        $sql = "SELECT Prod_Code, P_Description,  P_QtyOnHand, P_Price, V_Code FROM Product ORDER BY Prod_Code ASC;"; //note: ASC = ascending order
        $s = $db -> prepare($sql);
        $s -> execute();
        $s -> store_result();
        $s -> bind_result($pc, $desc, $qty, $price, $vc); //pc = product code, vc = vendor code
        $tableInfo = '';
        $counter = 0;
        while($s -> fetch())
        {
            $counter ++;
            $tableInfo .= '<tr>';
                $tableInfo .= '<td>'.$pc.'</td>';
                $tableInfo .= '<td>'.$desc.'</td>';
                $tableInfo .= '<td>'.$qty.'</td>';
                $tableInfo .= '<td>'.$price.'</td>';
                $tableInfo .= '<td>'.$vc.'</td>';
            $tableInfo .= '</tr>';
        }
        if(strlen($tableInfo) < 2) echo 'No Results';
        else 
        {
            echo "<table class = 'table'>
            <thead>
                <tr>
                    <th> Code </th>
                    <th> Description </th>
                    <th> On - Hand Quantity </th>
                    <th> Price </th>
                    <th> Vendor Code </th>
                <tr>
            </thead>
            <tbody>";
            echo $tableInfo;
            echo "</tbody>
            </table>";
        }
        return $counter;
    }
    function exactName($db, $name) //look for exact description
    {
        $sql = "SELECT Prod_Code, P_Description,  P_QtyOnHand, P_Price, V_Code FROM Product WHERE P_Description = '".$name."' ORDER BY Prod_Code ASC;"; //note: ASC = ascending order
        $s = $db -> prepare($sql);
        $s -> execute();
        $s -> store_result();
        $s -> bind_result($pc, $desc, $qty, $price, $vc); //pc = product code, vc = vendor code
        $tableInfo = '';
        $counter = 0;
        while($s -> fetch())
        {
            $counter ++;
            $tableInfo .= '<tr>';
                $tableInfo .= '<td>'.$pc.'</td>';
                $tableInfo .= '<td>'.$desc.'</td>';
                $tableInfo .= '<td>'.$qty.'</td>';
                $tableInfo .= '<td>'.$price.'</td>';
                $tableInfo .= '<td>'.$vc.'</td>';
            $tableInfo .= '</tr>';
        }
        if(strlen($tableInfo) < 2) echo 'No Results';
        else 
        {
            echo "<table class = 'table'>
            <thead>
                <tr>
                    <th> Code </th>
                    <th> Description </th>
                    <th> On - Hand Quantity </th>
                    <th> Price </th>
                    <th> Vendor Code </th>
                <tr>
            </thead>
            <tbody>";
            echo $tableInfo;
            echo "</tbody>
            </table>";
        }
        return $counter;
    }
?>
<?php mysqli_close($db);?>
