<?php
// code to add a new product to the database
ini_set("display_errors",1);
error_reporting(E_ALL);
$db = new mysqli('thekomanetskys.com', 'cs45Student26', 'Sdan3189@CS45', 'cs45Student26', 33066);
$p_code = trim($_POST['ProdCode']);
$desc = $_POST['ProdDesc']; //no need to trim I think (?)
$date = trim($_POST['InvDate']);
$q_onHand = trim($_POST['QtyOH']);
$q_min = trim($_POST['MinQty']);
$p_price = trim($_POST['ProdPrice']);
$discount = trim($_POST['DiscPct']); // in percentage!
$v_code = trim($_POST['vendors']);
$sql = "INSERT INTO Product VALUES (".$p_code.", '".$desc."', '".$date."', ".$q_onHand.", ".$q_min.", ".$p_price.", ".$discount.", ".$v_code.");";
if ($db->query($sql) === TRUE)  echo '<script>alert("Product Inserted Succesfully!");</script>';
else echo "Error: " . $sql . "<br>" . $db->error; //display error if not inserted appropiately
echo '<script>location.replace("index.html");</script>';
?>
<?php mysqli_close($db);?>
