<?php
    ini_set("display_errors",1); //display initial errors of connecting to db
    error_reporting(E_ALL);
    $db = new mysqli('thekomanetskys.com', 'cs45Student26', 'Sdan3189@CS45', 'cs45Student26', 33066);
    $code = trim($_POST['CustCode']);
?>
<!DOCTYPE html>
<html>
    <head>
    <title>Products Table</title>
		<!-- BOOTSTRAP FOR CSS LINK -->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <!-- HARD CODED CSS (by Shahaf Dan) -->
		<link rel = "stylesheet" type = "text/css" href = "../index.css" />
    </head>
    <body class = "body orangeback">
        <h1> Customer - Invoice Search Results </h1>
        <h4> cs45Student26 | Shahaf Dan</h4><br>
        <hr>
        <div class = "center framer">
            <?php $rows = custTable($db, $code); ?>
            <br>
            <h5> Total Results Returned: <?php echo $rows?> </h5>
        </div>
        <hr>
        <div class = "center">
            <button class = "btn btn-info inline" onclick = "location.replace('./listcustinv.html')";> Search Again</button>
            <button class = "btn btn-info inline" onclick = "location.replace('./index.html')";> Customer Home Page</button>
            <button class = "btn btn-info inline" onclick = "location.replace('../index.html')";> Main Home Page</button>
        </div>
    
    </body>
    <br><br>
	<footer class = "footer">
        <p>Las Positas College  |   CS 45 : Database Programming Course</p> 
        <p>Copyright, May 2020  |  cs45Student26 User of <u>www.thekomanetskys.com</u></p>
        <h6><strong>Produced and Powered by Shahaf Dan</strong> </h6>
    </footer></html>
<?php
    //FUNCTIONS::
    function custTable($db, $code)
    {
        $sql = "SELECT Inv_Number, Inv_Date, Cust_Code FROM Invoice WHERE Cust_Code = ".$code." ORDER BY Cust_Code ASC;";
        $s = $db -> prepare($sql);
        $s -> execute();
        $s -> store_result();
        $s -> bind_result($n, $d, $c); //n = name, d = date, c = code
        $tableInfo = '';
        $counter = 0;
        while($s -> fetch())
        {
            $tableInfo .= '<tr>';
            $tableInfo .= '<td>'.$n.'</td>';
            $tableInfo .= '<td>'.$d.'</td>';
            $tableInfo .= '<td>'.$c.'</td>';
            $tableInfo .= '</tr>';
            $counter++;
        }
        if(strlen($tableInfo) < 2) echo 'No Results';
        else 
        {
            echo "<table class = 'table'>
            <thead>
                <tr>
                    <th> Invoice Number (ID) </th>
                    <th> Invoice Date </th>
                    <th> Customer Code </th>
                <tr>
            </thead>
            <tbody>";
            echo $tableInfo;
            echo "</tbody>
            </table>";
        }
        return $counter;
    }
    mysqli_close($db);

?>