<?php
    ini_set("display_errors",1); //display initial errors of connecting to db
    error_reporting(E_ALL);
    $db = new mysqli('thekomanetskys.com', 'cs45Student26', 'Sdan3189@CS45', 'cs45Student26', 33066);
    $pname = trim($_POST['searchterm']);
?>
<!DOCTYPE html>
<html>
    <head>
    <title>Products Table</title>
		<!-- BOOTSTRAP FOR CSS LINK -->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <!-- HARD CODED CSS (by Shahaf Dan) -->
		<link rel = "stylesheet" type = "text/css" href = "../index.css" />
    </head>
    <body class = "body orangeback">
        <h1> Customer Search Results </h1>
        <h4> cs45Student26 | Shahaf Dan</h4><br>
        <hr>
        <div class = "center framer">
            <?php
            //functions to populate the table:
                if (isset($_POST['allCust'])) $rows = allCustTable($db, $pname);
                elseif(isset($_POST['similarto'])) $rows = similarToTable($db, $pname);
                else $rows = ExactName($db, $pname);
            ?>
            <br><br>
            <h5 class = "pull-left"> Results Returned: <?php echo $rows;?></h5>
            <br>        

        </div>
        <div class = "center">
            <button class = "btn btn-info inline" onclick = "location.replace('./index.html')";> Invoice Home Page</button>
            <button class = "btn btn-info inline" onclick = "location.replace('../index.html')";> Main Home Page</button>
            <button class = "btn btn-info inline" onclick = "location.replace('./listcust.html')";> Search Again</button>
        </div>
        <hr>
    </body>
    <footer class = "footer">
        <p>Las Positas College  |   CS 45 : Database Programming Course</p> 
        <p>Copyright, May 2020  |  cs45Student26 User of <u>www.thekomanetskys.com</u></p>
        <h6><strong>Produced and Powered by Shahaf Dan</strong> </h6>
    </footer>
</html>
<?php
    //FUNCTIONS::
    function similarToTable($db, $pname)
    {
        $sql = "SELECT Cust_Code, Cust_LName, Cust_FName FROM Customer WHERE Cust_LName LIKE '%".$pname."%' ORDER BY Cust_Code ASC;";
        $s = $db -> prepare($sql);
        $s -> execute();
        $s -> store_result();
        $s -> bind_result($c, $l, $f); //pc = product code, vc = vendor code
        $tableInfo = '';
        $counter = 0;
        while($s -> fetch())
        {
            $counter++;
            $tableInfo .= '<tr>';
                $tableInfo .= '<td>'.$c.'</td>';
                $tableInfo .= '<td>'.$l.'</td>';
                $tableInfo .= '<td>'.$f.'</td>';
            $tableInfo .= '</tr>';
        }
        if(strlen($tableInfo) < 2) echo 'No Results At The Moment';
        else 
        {
            echo "<table class = 'table'>
            <thead>
                <tr>
                    <th> Number (ID) </th>
                    <th> First Name </th>
                    <th> Last Name </th>
                <tr>
            </thead>
            <tbody>";
            echo $tableInfo;
            echo "</tbody>
            </table>";
        }
        return $counter;
    }
    function allCustTable($db)
    {
        $sql = "SELECT Cust_Code, Cust_LName, Cust_FName FROM Customer ORDER BY Cust_Code ASC;"; //note: ASC = ascending order
        $s = $db -> prepare($sql);
        $s -> execute();
        $s -> store_result();
        $s -> bind_result($c, $l, $f); //pc = product code, vc = vendor code
        $tableInfo = '';
        $counter = 0;
        while($s -> fetch())
        {
            $counter ++;
            $tableInfo .= '<tr>';
                $tableInfo .= '<td>'.$c.'</td>';
                $tableInfo .= '<td>'.$l.'</td>';
                $tableInfo .= '<td>'.$f.'</td>';
            $tableInfo .= '</tr>';
        }
        if(strlen($tableInfo) < 2) echo 'No Results At The Moment';
        else 
        {
            echo "<table class = 'table'>
            <thead>
                <tr>
                    <th> Number (ID) </th>
                    <th> First Name </th>
                    <th> Last Name </th>
                <tr>
            </thead>
            <tbody>";
            echo $tableInfo;
            echo "</tbody>
            </table>";
        }
        return $counter;
    }
    function ExactName($db, $name)
    {
        $sql = "SELECT Cust_Code, Cust_LName, Cust_FName FROM Customer WHERE Cust_LName = '".$name."' ORDER BY Cust_Code ASC;"; //note: ASC = ascending order
        $s = $db -> prepare($sql);
        $s -> execute();
        $s -> store_result();
        $s -> bind_result($c, $l, $f); //pc = product code, vc = vendor code
        $tableInfo = "";
        $counter = 0;
        while($s -> fetch())
        {
            $counter ++;
            $tableInfo .= '<tr>';
                $tableInfo .= '<td>'.$c.'</td>';
                $tableInfo .= '<td>'.$l.'</td>';
                $tableInfo .= '<td>'.$f.'</td>';
            $tableInfo .= '</tr>';
        }
        if(strlen($tableInfo) < 2) echo 'No Results At The Moment';
        else 
        {
            echo "<table class = 'table'>
            <thead>
                <tr>
                    <th> Number (ID) </th>
                    <th> First Name </th>
                    <th> Last Name </th>
                <tr>
            </thead>
            <tbody>";
            echo $tableInfo;
            echo "</tbody>
            </table>";
        }
        return $counter;
    }
    mysqli_close($db);

?>