<?php
    // code to add a new product to the database
    ini_set("display_errors",1); //display initial errors of connecting to db
    error_reporting(E_ALL);
    $db = new mysqli('thekomanetskys.com', 'cs45Student26', 'Sdan3189@CS45', 'cs45Student26', 33066);
    $c_code = trim($_POST['custNumber']);
    //if produc not found in the db: notify, go back
    //else: execute query
        //if query fails: notify, goback
        //else: success, go back
    $sql_check = "SELECT Cust_Code FROM Customer WHERE Cust_Code = ".$c_code.";";
    $s = $db -> prepare($sql_check);
    $s -> execute();
    $s -> store_result();
    $s -> bind_result($ccode); //is this line really necessary??
    if(!$s -> fetch()) //if query returns nothing = product not found
    {
        echo '<script>alert("Customer Code Not Found in the Database"); location.replace("delcust.html");</script>';      
    }
    else
    {
        $sql = "DELETE FROM Customer WHERE Cust_Code = ".$c_code.";";
        if ($db->query($sql) === TRUE)  echo '<script>alert("Product Deleted Succesfully!");</script>';
        else echo "<script>alert('ERROR: '".$db->error."');</script>"; //display error if not inserted appropiately
        echo '<script>location.replace("index.html");</script>';
    }
    mysqli_close($db);

   
?>