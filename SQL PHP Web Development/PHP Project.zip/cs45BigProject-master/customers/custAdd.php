<?php
    
    // code to add a new customer to the database
    ini_set("display_errors",1);
    error_reporting(E_ALL);
    $db = new mysqli('thekomanetskys.com', 'cs45Student26', 'Sdan3189@CS45', 'cs45Student26', 33066);
    $c_code = trim($_POST['CustCode']);
    $ln = $_POST['LastName']; //no need to trim I think (?)
    $fn = trim($_POST['FirstName']);
    $mi = trim($_POST['MidInitial']);
    $area = trim($_POST['AreaCode']);
    $pn = trim($_POST['TelNumber']);
    $balance = 0.0; //set initial balance for each new customer

    //check if the ID already exists (ALSO DO LATE VIA JS)
    $sql_check = "SELECT Cust_Code FROM Customer WHERE Cust_Code = ".$c_code.";";
    $s = $db -> prepare($sql_check);
    $s -> execute();
    $s -> store_result();
    $s -> bind_result($ccode);
    if(!$s -> fetch()) //if query returns nothing = customer ID does not exist! = good sign
    {
        $sql = "INSERT INTO Customer VALUES (".$c_code.", '".$ln."', '".$fn."', '".$mi."', ".$area.", ".$pn.", ".$balance.");";
        if ($db->query($sql) === TRUE)  echo '<script>alert("Customer Inserted Succesfully!");</script>';
        else echo "Error: " . $sql . "<br>" . $db->error; //display error if not inserted appropiately
        echo '<script>location.replace("index.html");</script>';
    }
    else
    {
        echo '<script>alert("The Customer Code you chose is already in use, please try a different one");</script>';
        echo '<script>location.replace("addcust.html");</script>';
    }
    mysqli_close($db);
?>