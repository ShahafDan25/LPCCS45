<?php $db = new mysqli('thekomanetskys.com', 'cs45Student26', 'Sdan3189@CS45', 'cs45Student26', 33066); ?>

<!DOCTYPE html>
<html>
<head>
		<title> Invoice Listing </title>
		<!-- BOOTSTRAP FOR CSS LINK -->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <!-- HARD CODED CSS (by Shahaf Dan) -->
		<link rel = "stylesheet" type = "text/css" href = "../index.css" />
		
	</head>
	<body class = "body blackback">
		<h1 class = "whitetext">List all Invoices</h1>
		<h4 class = "whitetext">cs45Student26 | Shahaf Dan</h4>
		<div class = "center framer">
			<table class = "table">
					<thead>
						<tr>
							<th> Invoice Number (ID) </th>
							<th> Date </th>
							<th> Customer Code </th>
							<th> Customer Name </th>
						<tr>
					</thead>
					<tbody>
						<?php
						//functions to populate the table:
							$rows = invoiceTable($db); 
							//I am going to have to use an inner join to get information from the customer table too
						?>
					</tbody>
			</table>
			<hr>
			<button class = "btn btn-info inline" onclick = "location.replace('./index.html')";> Invoice Home Page</button>
			<button class = "btn btn-info inline" onclick = "location.replace('../index.html')";> Main Home Page</button>
		</div>
	</body>
	<footer class = "footer">
        <p>Las Positas College  |   CS 45 : Database Programming Course</p> 
        <p>Copyright, May 2020  |  cs45Student26 User of <u>www.thekomanetskys.com</u></p>
        <h6><strong>Produced and Powered by Shahaf Dan</strong> </h6>
    </footer>
</html>


<?php
	//FUNCTION :
	function invoiceTable($c)
	{
		$sql = "SELECT a.Inv_Number, a.Inv_Date, a.Cust_Code, b.Cust_FName, b.Cust_LName, b.Cust_MInitial FROM Invoice a JOIN Customer b ON b.Cust_Code = a.Cust_Code;";
		$s = $c -> prepare($sql);
        $s -> execute();
        $s -> store_result();
		$s -> bind_result($n, $d, $c, $f, $l, $m);
		//n = number, d = date, c = code, f = firstName, l = lastName, m = middleInitial
        $tableInfo = '';
        $counter = 0;
        while($s -> fetch())
        {
            echo '<tr>';
                echo '<td>'.$n.'</td>';
                echo '<td>'.$d.'</td>';
                echo '<td>'.$c.'</td>';
                echo '<td>'.$f.'  '.$m.'.  '.$l.'</td>'; //print full name!
            echo '</tr>';
            $counter++;
        }
		return $counter;
	}
?>
<?php mysqli_close($db);?>
