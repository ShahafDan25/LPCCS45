<?php
// code to add a new product to the database
    ini_set("display_errors",1);
    error_reporting(E_ALL);
    $db = new mysqli('thekomanetskys.com', 'cs45Student26', 'Sdan3189@CS45', 'cs45Student26', 33066);
    $n = trim($_POST['invNumber']); //n = number
    $l = trim($_POST['LineNumber']); //d = date
    $c = trim($_POST['prodNumber']); //c = code
    $u = trim($_POST['UnitsOrdered']); //u = units
    $p = trim($_POST['ItemPrice']); //p = price (single)

    
    $sql = "INSERT INTO LineItem VALUES (".$n.", ".$c.", ".$l.", ".$u.", ".$p.");";
    if ($db->query($sql) === TRUE)  echo '<script>alert("Line Item Inserted Succesfully!");</script>';
    else echo '<script>alert("ERROR in Inserting LineItem: '.$db->error.'");</script>';
    echo '<script>location.replace("index.html");</script>';
?>
<?php mysqli_close($db);?>
