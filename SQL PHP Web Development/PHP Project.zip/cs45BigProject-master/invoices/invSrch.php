<?php
    ini_set("display_errors",1); //display initial errors of connecting to db
    error_reporting(E_ALL);
    $db = new mysqli('thekomanetskys.com', 'cs45Student26', 'Sdan3189@CS45', 'cs45Student26', 33066);
    $code = trim($_POST['invCode']);
?>
<!DOCTYPE html>
<html>
    <head>
    <title>Invoice Table</title>
		<!-- BOOTSTRAP FOR CSS LINK -->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <!-- HARD CODED CSS (by Shahaf Dan) -->
		<link rel = "stylesheet" type = "text/css" href = "../index.css" />
    </head>
    <body class = "body blackback">
        <h1 class = "whitetext"> Invoice Search Results </h1>
        <h4 class = "whitetext">cs45Student26 | Shahaf Dan</h4>
        <hr>
        <?php
            $sql = "SELECT a.Inv_Number, a.Inv_Date, a.Cust_Code, b.Cust_LName, b.Cust_FName, b.Cust_MInitial FROM Invoice a JOIN Customer b ON b.Cust_Code = a.Cust_Code WHERE a.Inv_Number = ".$code.";";
            $s = $db -> prepare($sql);
            $s -> execute();
            $s -> store_result();
            $s -> bind_result($n ,$d, $c, $l, $f, $m); //n = number, d = date, c = code, f = firstName, l = lastName, m = middleInitial
            if($s -> fetch())
            {
                echo '<p class = "whitetext"> Invoice Number <strong><u>';
                echo $n;
                echo ' </u></strong> was ordered on <strong><u>';
                echo $d;
                echo ' </u></strong> by customer <strong><u>';
                echo $n." [ ".$f." ".$m.". ".$l." ]";
                echo '</u></strong> </p>';
            } 
            else
            {
                echo '<div class = "center"><p class = "whitetext">No Invoice Was Found in the Database</p></div>';
            }
        ?>
        <div class = "center framer"><?php populateTable($db, $code);?> </div>  
        <hr>
        <div class = "center">
            <button class = "btn btn-info inline" onclick = "location.replace('./srchinv.html')";> Search Again </button>
            <button class = "btn btn-info inline" onclick = "location.replace('./index.html')";> Invoice Home Page</button>
            <button class = "btn btn-info inline" onclick = "location.replace('../index.html')";> Main Home Page</button>
        </div>
        <br>
    </body>
    
    <footer class = "footer">
        <p>Las Positas College  |   CS 45 : Database Programming Course</p> 
        <p>Copyright, May 2020  |  cs45Student26 User of <u>www.thekomanetskys.com</u></p>
        <h6><strong>Produced and Powered by Shahaf Dan</strong> </h6>
    </footer>
</html>
<?php
    //FUNCTIONS::, $code
    function populatetable($db, $code)
    {
        $counter = 0;
        $totalPrice = 0.0;
        $sql = "SELECT a.Prod_Code, a.Line_Units, a.Line_Price, a.Line_Price * a.Line_Units, b.P_Description FROM LineItem a JOIN Product b ON b.Prod_Code = a.Prod_Code WHERE a.Inv_Number = ".$code.";";
        $s = $db -> prepare($sql);
        $s -> execute();
        $s -> store_result();
        $s -> bind_result($c ,$u, $p, $e, $d); 
        //c = code, u = units, p = price (single), e = extension, d = description (of product)
        $tableInfo = "";
        while($s -> fetch())
        {
            $totalPrice += $e;
            $counter++;
            $tableInfo .= '<tr>';
                $tableInfo .= '<td>'.$counter.'</td>';
                $tableInfo .= '<td><strong>'.$c.' ~ </strong>'.$d.'</td>';
                $tableInfo .= '<td>'.$u.'</td>';
                $tableInfo .= '<td>'.$p.'</td>';
                $tableInfo .= '<td>'.$e.'</td>';
            $tableInfo .= '</tr>';
        }
        if(strlen($tableInfo) < 2) echo 'No Results At The Moment';
        else 
        {
            echo "<table class = 'table'>
            <thead>
                <tr>
                    <th> Item  </th>
                    <th> Product </th>
                    <th> Quantity </th>
                    <th> Price </th>
                    <th> Total Line </th>
                <tr>
            </thead>
            <tbody>";
            echo $tableInfo;
            echo "</tbody>
            </table><br><h5> Total Price For This Order: ".$totalPrice."</h5>";
        }
        return $totalPrice;
    }

    
?>
<?php mysqli_close($db);?>
