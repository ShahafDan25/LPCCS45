<?php 
	ini_set("display_errors",1);
    error_reporting(E_ALL);
	$db = new mysqli('thekomanetskys.com', 'cs45Student26', 'Sdan3189@CS45', 'cs45Student26', 33066);
?>

<!DOCTYPE html>
<html>
	<head>
	<title>Add LineItem - Invoice</title>
		<!-- BOOTSTRAP FOR CSS LINK -->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <!-- HARD CODED CSS (by Shahaf Dan) -->
		<link rel = "stylesheet" type = "text/css" href = "../index.css" />
		
	</head>
	<body class = "body blackback">
		<h1 class = "whitetext">Add a New Invoice Line Item</h1>
		<h4 class = "whitetext">cs45Student26 | Shahaf Dan</h4>
		<p class = "whitetext">This form will call the <strong>lineitemAdd.php</strong> file which will insert an line item into the LineItem table</p>
		<div class = "center framer">
			<form action="lineitemAdd.php" method="post">
				<table class = " table">
						<tr>
							<td class = "pull-left"><strong>Invoice Number: </strong> </td>
							<td><select class = "input" name="invNumber">
							<?php
								$sql = "SELECT Inv_Number, Inv_Date FROM Invoice";
								$s = $db -> prepare($sql);
								$s -> execute();
								$s -> store_result();
								$s -> bind_result($n, $d); //n = number, d = date
								while($s -> fetch())
								{
									echo '<option value = '.$n.'><strong>'.$n.'</strong> [ '.$d.' ] </option>';
								}
							?>
							</select></td>
						</tr>
						<tr>
							<td class = "pull-left"><strong>Line Number (7 digits): </strong></td>
							<td><input placeholder = "  Line Number" id = "idInput" class = "input" placehodler = "  Line Number" name="LineNumber" type="number" min="1" max="9999999"></td>
						</tr>
						<p id = "alertedIDdiv"></p>
						<tr>
							<td class = "pull-left"><strong>Product Number: </strong> </td>
							<td><select class = "input" name="prodNumber">
							<?php
								$sql = "SELECT Prod_Code FROM Product";
								$s = $db -> prepare($sql);
								$s -> execute();
								$s -> store_result();
								$s -> bind_result($p); //p = product (id)
								while($s -> fetch())
								{
									echo '<option value = '.$p.'><strong>'.$p.'</strong></option>';
								}
							?> </p>
							</select></td>
						</tr>
						<tr>
							<td class = "pull-left"><strong>Units Ordered (1-10): </strong></td>
							<td><input placeholder = "  Units" class = "input" name="UnitsOrdered" type="number" min="1" max="10"></td>
						</tr>
						<tr>
							<td class = "pull-left"><strong>Item Price: </strong></td>
							<td><input class = "input" placeholder = "  Item Price" name="ItemPrice" type="number" placeholder="0.00" min=".01" max="9999.99" step="0.01"></td>
						</tr>
				</table>
				<button class = "btn btn-success"> SUBMIT </button>
			</form>
			<hr>
			<button class = "btn btn-info inline" onclick = "location.replace('./index.html')";> Invoice Home Page</button>
			<button class = "btn btn-info inline" onclick = "location.replace('../index.html')";> Main Home Page</button>
		</div>
	</body>
	<footer class = "footer">
        <p>Las Positas College  |   CS 45 : Database Programming Course</p> 
        <p>Copyright, May 2020  |  cs45Student26 User of <u>www.thekomanetskys.com</u></p>
        <h6><strong>Produced and Powered by Shahaf Dan</strong> </h6>
	</footer>
	<script>
		var ids = new Array(<?php echo populateArrayWithIds($db); ?>);
		var idInput = document.getElementById("idInput");
		idInput.onkeyup = function(event){
			if (event.target.value.length == 0) document.getElementById("alertedIDdiv").innerHTML = "";
			else if(event.target.value.length != 7) document.getElementById("alertedIDdiv").innerHTML = "Line Number has to be 7 digits!";
			else 
			{
				if(ids.includes(event.target.value)) document.getElementById("alertedIDdiv").innerHTML = "ALERT: This ID is already in use!";
				else document.getElementById("alertedIDdiv").innerHTML = "ID availability confirmed";
			}
		}
	</script>
</html>
<?php
	function populateArrayWithIds($db)
	{
		$idsArrays = "";
        $sql = "SELECT Line_Number FROM LineItem";
		$s = $db -> prepare($sql);
		$s -> execute();
		$s -> store_result();
		$s -> bind_result($c);
		$s -> fetch();
        $idsArrays .= '"'.$c.'"'; //c is for code
        while ($s->fetch())
        { 
            $idsArrays .= ', "'.$c.'"';
        }
		return $idsArrays;
	}
	mysqli_close($db);
?>






	