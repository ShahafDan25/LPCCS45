<?php
// code to add a new product to the database
    ini_set("display_errors",1);
    error_reporting(E_ALL);
    $db = new mysqli('thekomanetskys.com', 'cs45Student26', 'Sdan3189@CS45', 'cs45Student26', 33066);
    $c = trim($_POST['InvCode']); //c = code
    $d = trim($_POST['InvDate']); //d = date
    $cc = trim($_POST['customers']); //cc = customer code
    $sql = "INSERT INTO Invoice VALUES (".$c.", '".$d."', ".$cc.");";
    if ($db->query($sql) === TRUE)  echo '<script>alert("Invoice Inserted Succesfully!");</script>';
    else echo "Error: " . $sql . "<br>" . $db->error; //display error if not inserted appropiately
    echo '<script>location.replace("index.html");</script>';
?>
<?php mysqli_close($db);?>
