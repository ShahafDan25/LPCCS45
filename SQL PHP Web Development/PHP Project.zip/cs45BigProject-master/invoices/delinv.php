<?php
    ini_set("display_errors",1); //display initial errors of connecting to db
    error_reporting(E_ALL);
    $db = new mysqli('thekomanetskys.com', 'cs45Student26', 'Sdan3189@CS45', 'cs45Student26', 33066);
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Delete  Invoice</title>
		<!-- BOOTSTRAP FOR CSS LINK -->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <!-- HARD CODED CSS (by Shahaf Dan) -->
		<link rel = "stylesheet" type = "text/css" href = "../index.css" />
		
	</head>
	<body class = "body blackback">
		<h1 class = "whitetext">Delete Existing Invoice</h1>
		<h4 class = "whitetext">cs45Student26 | Shahaf Dan</h4>
		<p class = "whitetext">This form will call the <strong>invDelete.php</strong> file which will delete an invoice and all invoice line items associated with that invoice\</p>
		<div class = "center framer">
			<form action="invDelete.php" method="post">
				<p class = "wm40"><strong>Enter Invoice Code</strong> <input id = "idInput" class = "input" placeholder="  Invioce Code" name="invCode" type="number" min="1" max="999999"></p>
				<p id = "alertedIDdiv"></p>
				<button class = "btn btn-success"> SUBMIT </button>
			</form>			<hr>
			<button class = "btn btn-info inline" onclick = "location.replace('./index.html')";> Invoice Home Page</button>
			<button class = "btn btn-info inline" onclick = "location.replace('../index.html')";> Main Home Page</button>
		</div>
	</body>
	<footer class = "footer">
        <p>Las Positas College  |   CS 45 : Database Programming Course</p> 
        <p>Copyright, May 2020  |  cs45Student26 User of <u>www.thekomanetskys.com</u></p>
        <h6><strong>Produced and Powered by Shahaf Dan</strong> </h6>
    </footer>
	<script>
		var ids = new Array(<?php echo populateArrayWithIds($db); ?>);
		var idInput = document.getElementById("idInput");
		idInput.onkeyup = function(event){
			if (event.target.value.length == 0) document.getElementById("alertedIDdiv").innerHTML = "";
			else if(event.target.value.length != 6) document.getElementById("alertedIDdiv").innerHTML = "Invoice Number has to be 6 digits!";
			else 
			{
				if(ids.includes(event.target.value)) document.getElementById("alertedIDdiv").innerHTML = "ALERT: This ID is already in use!";
				else document.getElementById("alertedIDdiv").innerHTML = "ID availability confirmed";
			}
		}
	</script>
</html>
<?php
	function populateArrayWithIds($db)
	{
		$idsArrays = "";
        $sql = "SELECT Inv_Number FROM Invoice";
		$s = $db -> prepare($sql);
		$s -> execute();
		$s -> store_result();
		$s -> bind_result($c);
		$s -> fetch();
        $idsArrays .= '"'.$c.'"'; //c is for code
        while ($s->fetch())
        { 
            $idsArrays .= ', "'.$c.'"';
        }
		return $idsArrays;
	}
	mysqli_close($db);
?>

