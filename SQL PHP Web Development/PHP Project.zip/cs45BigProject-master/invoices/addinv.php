<?php $db = new mysqli('thekomanetskys.com', 'cs45Student26', 'Sdan3189@CS45', 'cs45Student26', 33066); ?>
<!DOCTYPE html>
<html>
	<head>
		<title>Add Invoice</title>
		<!-- BOOTSTRAP FOR CSS LINK -->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <!-- HARD CODED CSS (by Shahaf Dan) -->
		<link rel = "stylesheet" type = "text/css" href = "../index.css" />
		
	</head>
	<body class = "body blackback">
		<h1 class = "whitetext"> Add New Invoice</h1>
		<h4 class = "whitetext">cs45Student26 | Shahaf Dan</h4>
		<p class = "whitetext">This form will call the <strong>invAdd.php</strong> file which will insert an invoice into the invoice table</p>
		<div class = "center framer">
			<form action="invAdd.php" method="post">
				<p id = "alertedIDdiv"></p>
				<table class = " table">
					<tr>
						<td class = "pull-left"><strong>Invoice Number (100000-999999): </strong></td>
						<td><input class = "input" id = "idInput" placeholder = "  Invoice Number" name="InvCode" type="number" min="1" max="999999"></td>
					</tr>
					<tr>
						<td class = "pull-left"><strong>Invoice Date (yyyy-mm-dd): </strong></td>
						<td><input class = "input" placeholder = "  Invoice Date" name="InvDate" type="text"></td>
					</tr>
					<tr>
						<td class = "pull-left"><strong>For Customer: </strong> </td>
						<td><select name="customers" class = "input">
							<?php
								$sql = "SELECT Cust_Code, Cust_Fname, Cust_MInitial, Cust_Lname FROM Customer";
								$s = $db -> prepare($sql);
								$s -> execute();
								$s -> store_result();
								$s -> bind_result($c, $f, $l, $m); //c = code, f = firstName, l = lastName, m = middleinitial
								while($s -> fetch())
								{
									echo '<option value = '.$c.'>'.$f.' '.$m.'. '.$l.' [ '.$c.' ] </option>';
								}
							?>
						</select></td>
					</tr>
				</table>
				<button class = "btn btn-success"> SUBMIT </button>
			</form>
			<hr>
			<button class = "btn btn-info inline" onclick = "location.replace('./index.html')";> Invoice Home Page</button>
			<button class = "btn btn-info inline" onclick = "location.replace('../index.html')";> Main Home Page</button>
			<br>
		</div>
	</body>
	<footer class = "footer">
        <p>Las Positas College  |   CS 45 : Database Programming Course</p> 
        <p>Copyright, May 2020  |  cs45Student26 User of <u>www.thekomanetskys.com</u></p>
        <h6><strong>Produced and Powered by Shahaf Dan</strong> </h6>
    </footer>

<script>
		var ids = new Array(<?php echo populateArrayWithIds($db); ?>);
		var idInput = document.getElementById("idInput");
		idInput.onkeyup = function(event){
			if (event.target.value.length == 0) document.getElementById("alertedIDdiv").innerHTML = "";
			else if(event.target.value.length != 6) document.getElementById("alertedIDdiv").innerHTML = "Invoice Number has to be 6 digits!";
			else 
			{
				if(ids.includes(event.target.value)) document.getElementById("alertedIDdiv").innerHTML = "ALERT: This ID is already in use!";
				else document.getElementById("alertedIDdiv").innerHTML = "ID availability confirmed";
			}
		}
	</script>
</html>
<?php
	function populateArrayWithIds($db)
	{
		$idsArrays = "";
        $sql = "SELECT Inv_Number FROM Invoice";
		$s = $db -> prepare($sql);
		$s -> execute();
		$s -> store_result();
		$s -> bind_result($c);
		$s -> fetch();
        $idsArrays .= '"'.$c.'"'; //c is for code
        while ($s->fetch())
        { 
            $idsArrays .= ', "'.$c.'"';
        }
		return $idsArrays;
	}
	mysqli_close($db);
?>

