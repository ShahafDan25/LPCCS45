
<!DOCTYPE html>
<html>
	<head>
		<title>Employee Search Results </title>
		<style>
		table, th, td {
                                border: 1px solid black;
                                text-align: center;
                                padding: 1px !important;
			}
		th {background-color: cyan;}
		table{border-radius:5px;}
	 	.btn
                                {
                                        border-radius:5px;
                                        padding: 1% !important;
                                        background-color: pink;
                                        border: 2px solid black;
                                }
		</style>
	</head>
	<body>
		<h1> EMPLOYEE SEARCH RESULTS </h1> 
<h3> MENU </h3>
<button class = "btn" onclick = location.replace('search.html')> Search for More </button>
                        <button class = "btn" onclick = location.replace('index.html')> Home Page (index) </button> <br><hr>
<?php
			$searchTerm = trim($_POST['searchTerm']);
			if(!$searchTerm)
			{
				echo '<p> You did not enter a search term </p>';
				echo '<p> Please go back and try again </p>';


				echo '<script> alert ("Dont make mistake anymore please"); </script>';
				exit;
			}
			else
			{
				echo '<p> SEARCHING FOR ' .$searchTerm.'</p>';
				$db = new mysqli('thekomanetskys.com', 'cs45Student26', 'Sdan3189@CS45', 'employees', 33066);
				if(mysqli_connect_errno())
				{
					echo '<p> ERROR CONNECTING to the database </p>';
					echo '<script> alert("PLEASE CONSIDER GOING BACK"); </script>';
				}
				
				else
				{

					echo $db->host_info. "\n";
					if($searchTerm == "ALL")
					{

						$query = "SELECT emp_no, first_name, last_name FROM employees";
						$stmt = $db->prepare($query);
					}
					else
					{
						
						$query = "SELECT emp_no, first_name, last_name  FROM employees WHERE last_name = ? ORDER BY emp_no ASC";
						$stmt = $db->prepare($query);
                                        	$stmt->bind_param("s", $searchTerm);
					}
					$stmt->execute();
					$stmt->store_result();
					$stmt->bind_result($empNO,$firstName,$lastName);
					echo "<p> Number of employees found:".$stmt->num_rows."</p>";
					
					echo '<table style="width:100%">';
					echo '<thead>';
						echo '<tr>';
							echo '<th> <strong> ~ Employee ID ~ </strong>  </th>';
							echo '<th> <strong> ~ Last Name ~ </strong> </th>';		
							echo '<th> <strong> ~ First Name ~ </strong> </th>';
						echo '</tr>';		
					echo '</thead>';
					echo '<tbody>';

					
					while($stmt -> fetch())
					{
						echo '<tr>';
						echo '<td>'.$empNO.'</td>';
						echo '<td>'.$firstName.'</td>';
						echo '<td>'.$lastName.'</td>';
						echo '</tr>';
					}//end of while
					echo '</tbody></table>';
					
					echo'</table>';
					$stmt -> free_results();
					$db -> close(); //close connection to the database
				}
			
			}
		?>
		</body>
	</html>
