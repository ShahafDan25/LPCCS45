<!DOCTYPE html>
<html>
	<head>
		<title> Delete Employee </title>
		<style>
			.selectter
			{
				background-color: green;
					border-radius: 25px;
						border: 2px solid black;
			}
			.btn
			{
				background-color: red;
				color: white;
				size: 20px;
				border-radius: 5px;
				border: 2px solid white;
				padding: 1.5% !important;
				margin: 1px;	
			}
		</style>
	</head>

	<body>
		<h1> Delete an Employee by following the instryctions below! </h1>
		<h3> Instructions </h3>
		<ul>
			<li> Select an employee number from the drop down below </li>
			<li> Click Submit </li>
			<li> a confirmation page should pop up, if it did not, something went wrong and you should either try again, or contact the meila mentioned below <li>
	
		</ul>
		<br><hr><br>
		<form action = "delempmsg.php" method = "post">
		<select name = "empnoSelect"  class = "selectter">

			<option value = "0"> NO EMPLOYEED TO DISPLAY </option>
			<?php
				ini_set("display_errors",1);
				error_reporting(E_ALL);
				$db = new mysqli('thekomanetskys.com', 'cs45Student26', 'Sdan3189@CS45', 'employees', 33066);
				if (mysqli_connect_errno())
				{
					echo '<option value="1">Bad SQL Connection</option>';
				}
				else 
				{
					$query = "SELECT emp_no FROM employees";
					$stmt = $db->prepare($query);
					$stmt->execute();
					$stmt->store_result();
					$stmt->bind_result($deptNumber);
					while($stmt->fetch()) 
					{
						echo '<option value=\"'.$deptNumber.'/">'.$deptNumber.'</option>';
					}
					mysqli_close($db); //close connection. I HONESTLY REALLY WOULD PREFER TO USE PDO. SO MUCH EASIER!
				}

			?>
		</select> <br><br>
		<button class = "btn"><strong>  Submit </strong> </button> <br>	
		</form>
	</body>

	<footer>
		<hr>
		<br>
		<h4> Contact Information </h4>
		<p> Name: Shahaf Dan </p>
		<p> User ID: cs45Student26 </p>
		<p> email: sxdan@zonemail.clpccd.edu</p>
	</footer>
</html>
