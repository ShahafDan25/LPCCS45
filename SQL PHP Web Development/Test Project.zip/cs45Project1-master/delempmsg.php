<!DOCTYPE html>
	<html>
		<head>
			<title> Action: Delete Employee, Message </title>
			<style>
				.btn	
				{
					border-radius:5px;
					padding: 1% !important;
					background-color: pink;
					bordeR: 2px solid black;
				}	

			</style>
		</head>
		<body>
			<h1> <u> Action </u>: Delete Employee, <strong> Message: </strong> </h1>
			<h3> MENU: </h3>
			<button class = "btn" onclick = location.replace('delemp.php')> Delete More </button>
			<button class = "btn" onclick = location.replace('index.html')> Home Page (index) </button> <br><hr>
			<h4> The following is a message as a result of your deletion of the employee you had chosen </h4>
			<?php
				ini_set("display_errors",1);
				error_reporting(E_ALL);
				$empNumber = substr(trim($_POST['empnoSelect']), 2);
				$empNumber = substr($empNumber, 0, -2);
				
				//next: connect to db with db variable
				$db = new mysqli('thekomanetskys.com', 'cs45Student26', 'Sdan3189@CS45', 'employees', 33066);
				//now chck the connection
				 if($empNumber == "0" || $empNumber == "1")
                                 {
                                           echo'<script>alert("You did not choose a valid employee form the drop down, please go back!"); </script>';
   	                                   echo '<h2> Please go back a page, you did not choose a valie option </h2>';
               	  	             }
				 else if (mysqli_connect_errno()) 
				{
					echo '<p>Error connecting to the database</p>';
					echo '<p>Contact our database administrator for help</p>';
					echo '<p>Or, go-back and try again</p>';
				}
				else 
				{
					echo $db->host_info . "\n";
					$query = "DELETE FROM employees WHERE emp_no = ?";
					
					$stmt = $db->prepare($query);
					$stmt->bind_param('i', $empNumber);
				       $stmt->execute();	//execute deltion!					
					if($stmt->affected_rows > 0) //will see if any rows were deleted
					{
						echo '<script> alert("Employee has been deleted succesfully"); </script>';
						
					}
					else 
					{
						echo '<script>alert(" ERROR: could not delete the employee. Please contact the manager with the email provided below, or try again later"); </script>';
						 
					 } // end second else
					$stmt->free_result();
					$db->close();
				} //end third else
			?>
		</body>

		<footer>
			<br><br>
			<h4> Manager's Contact Information </h4>
			<hr>
			<ul>
				<li> <u> Name</u>: Shahaf Dan </li>
				<li> <u> email</u>: sxdan@zonemail.clpccd.edu </li>
				<li> <u> Database Username</u>: cs45Student26 </li>
			</ul>
		</footer>
	</html>

