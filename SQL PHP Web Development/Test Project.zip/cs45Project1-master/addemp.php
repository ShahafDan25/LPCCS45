<!DOCTYPE html>
	<html>
		<head>
			<title>Add Employee Results</title>
			<style>
 .btn
                                {
                                        border-radius:5px;
                                        padding: 1% !important;
                                        background-color: pink;
                                        bordeR: 2px solid black;
                                }
</style>
		</head>
	<body>
		<h1>Add Employee Results</h1>

		<h3> MENU: </h3>
			<button class = "btn" onclick = location.replace('addemp.html')> Add  More </button>
                        <button class = "btn" onclick = location.replace('index.html')> Home Page (index) </button> <br><hr>
		<?php

			ini_set("display_errors",1);
			error_reporting(E_ALL);
			$empNumber = trim($_POST['EmpNumber']);
			$empNumber = intval($empNumber);

			$lastName = trim($_POST['LastName']);
			$firstName = trim($_POST['FirstName']);
			if (!$empNumber or !$lastName or !$firstName) {
				echo '<p>You did not enter all input fields as required</p>';
				echo '<p>Please go-back and try again</p>';
				exit;}
			else {echo '<p>Trying to add '.$empNumber.'</p>';}

			$db = new mysqli('thekomanetskys.com', 'cs45Student26', 'Sdan3189@CS45', 'employees', 33066);
			if (mysqli_connect_errno()) {
				echo '<p>Error connecting to the database</p>';
				echo '<p>Contact our database administrator for help</p>';
				echo '<p>Or, go-back and try again</p>';}
		       	else {
				echo $db->host_info . "\n";
			}//end of ifelse block
				//
			$query = "INSERT INTO employees (emp_no, last_name, first_name) VALUES (?, ?, ?)";
			$stmt = $db->prepare($query);
			$stmt->bind_param('iss', $empNumber, $lastName, $firstName);
			$stmt->execute();
			if($stmt->affected_rows > 0) {echo '<p>Employee inserted successfully</p>';}
			else {echo '<p>Error inserting employee</p>';}
			$db->close();

		?>
	</body>
</html>
